Environment Setup :
- Visual Studio 2013
- Uses Windows environment variable BWAPI_DIR which points to BWAPI 4.1.2
  (ex : BWAPI_DIR = C:\StarCraft\bwlibrary\BWAPI412)
How To Compile :
- Open src/XiaoYi.sln in VS2013
- Select Release_Server_DLL mode
- Build the XiaoYi project
- Output will go to src/Release_Server_DLL/XiaoYi/XiaoYi.dll

References :
UAlberta Bot (Thanks to Author : David Churchill)
BWEM (Map Analyzer, Thanks to Author : Igor Dimitrijevic)
SAIDA (Thanks to Author :Samsung Artificial Intelligence & Data Analytics)


